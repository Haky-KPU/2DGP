from pico2d import *

Location_X = 400
Location_Y = 300

running = false;

def handle_events():
    events = get_events()
    for event in events:
        if event.type == SDL_KEYDOWN and event.key == SDLK

def main():

    global running

    running = True
    while running:
        handle_events()