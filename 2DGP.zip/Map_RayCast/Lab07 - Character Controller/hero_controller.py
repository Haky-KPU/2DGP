# hero_controller.py : control hero move with left and right key

import random
from pico2d import *
import json

running = None
hero = None
Map_RayCast_data = None
Location = None
class Grass:
    def __init__(self):
        self.image = load_image('grass.png')

    def draw(self):
        self.image.draw(400, 30)


class Hero:
    image = None
    LUP_RUN, UP_RUN, RUP_RUN = 7, 8, 9
    LEFT_RUN, LEFT_STAND, RIGHT_RUN, RIGHT_STAND,  = 4, 41, 6, 61
    LDOWN_RUN, DOWN_RUN, RDOWN_RUN = 1, 2, 3
    SPEED_WALK, SPEED_RUN = 5, 10

    LUP, UP, RUP = 7, 8, 9
    LEFT, All, RIGHT = 4, 5, 6
    LDOWN, DOWN, RDOWN = 1, 2, 3
    def __init__(self):
        self.x, self.y = random.randint(100, 700), 90
        self.frame = random.randint(0, 7)
        self.state = self.RIGHT_STAND
        self.speed = self.SPEED_WALK
        self.imgsheet = 0
        if Hero.image == None:
            Hero.image = load_image('animation_sheet.png')

    def handle_event(self, event):
        if(event.type, event.key) == (SDL_KEYDOWN, SDLK_LEFT):#LEFT_DOWN
            if self.state in (self.RIGHT_STAND, self.LEFT_STAND):#L_R
                self.state = self.LEFT_RUN

            elif self.state in (self.RIGHT_RUN,):
                self.state = self.LEFT_RUN

            elif self.state in (self.UP_RUN, ):#LUP_R
                self.state = self.LUP_RUN

            elif self.state in (self.DOWN_RUN, ):#LDOWN_R
                self.state = self.LDOWN_RUN

        elif (event.type, event.key) == (SDL_KEYUP, SDLK_LEFT):#LEFT_UP
            if self.state in (self.LEFT_RUN,):
                self.state = self.LEFT_STAND

            elif self.state in (self.LUP_RUN,):
                self.state = self.UP_RUN

            elif self.state in (self.LDOWN_RUN,):
                self.state = self.DOWN_RUN

        elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_RIGHT):#RIGHT_DOWN
            if self.state in (self.RIGHT_STAND, self.LEFT_STAND):
                self.state = self.RIGHT_RUN

            elif self.state in (self.LEFT_RUN,):
                self.state = self.RIGHT_RUN

            elif self.state in (self.UP_RUN,):  # RUP_R
                self.state = self.RUP_RUN

            elif self.state in (self.DOWN_RUN,):  # RDOWN_R
                self.state = self.RDOWN_RUN

        elif (event.type, event.key) == (SDL_KEYUP, SDLK_RIGHT):#RIGHT_UP
            if self.state in (self.RIGHT_RUN,):
                self.state = self.RIGHT_STAND

            elif self.state in (self.RUP_RUN,):
                self.state = self.UP_RUN

            elif self.state in (self.RDOWN_RUN,):
                self.state = self.DOWN_RUN

        elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_UP):#UP_DOWN
            if self.state in (self.RIGHT_STAND, self.LEFT_STAND):
                self.state = self.UP_RUN

            elif self.state in (self.DOWN_RUN,):
                self.state = self.UP_RUN

            elif self.state in (self.RIGHT_RUN,):  # RUP_R
                self.state = self.RUP_RUN

            elif self.state in (self.LEFT_RUN,):  # RDOWN_R
                self.state = self.LUP_RUN

        elif (event.type, event.key) == (SDL_KEYUP, SDLK_UP):#UP_UP
            if self.state in (self.UP_RUN,):
                self.state = self.RIGHT_STAND

            elif self.state in (self.RUP_RUN,):
                self.state = self.RIGHT_RUN

            elif self.state in (self.LUP_RUN,):
                self.state = self.LEFT_RUN

        elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_DOWN):  # DOWN_DOWN
            if self.state in (self.RIGHT_STAND, self.LEFT_STAND):
                self.state = self.DOWN_RUN

            elif self.state in (self.UP_RUN,):
                self.state = self.DOWN_RUN

            elif self.state in (self.RIGHT_RUN,):  # RUP_R
                self.state = self.RDOWN_RUN

            elif self.state in (self.LEFT_RUN,):  # RDOWN_R
                self.state = self.LDOWN_RUN

        elif (event.type, event.key) == (SDL_KEYUP, SDLK_DOWN):  # DOWN_UP
            if self.state in (self.DOWN_RUN,):
                self.state = self.LEFT_STAND

            elif self.state in (self.RDOWN_RUN,):
                self.state = self.RIGHT_RUN

            elif self.state in (self.LDOWN_RUN,):
                self.state = self.LEFT_RUN

        elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_SPACE):
            self.speed = self.SPEED_RUN
        elif (event.type, event.key) == (SDL_KEYUP, SDLK_SPACE):
            self.speed = self.SPEED_WALK

    def Open_RayCast(self):
        #txt 파일로 저장된 맵 충돌 체크 파일 호출.
        global Map_RayCast_data

        Map_RayCast_data_file = open('Map_RayCast_data.txt', 'r')
        Map_RayCast_data = json.load(Map_RayCast_data_file)
        Map_RayCast_data_file.close()

    def update(self):
        global Map_RayCast_data
        global Location

        Location = [int((self.x / 10)), int((self.y / 10))]

        self.frame = (self.frame + 1) % 8

        if self.state == self.LDOWN_RUN:
            self.x = max(0, self.x - self.speed)
            self.y = max(0, self.y - self.speed)

        elif self.state == self.DOWN_RUN:
            if Map_RayCast_data[Location[1]][Location[0]] in (self.DOWN, self.All):
                self.y = max(0, self.y - self.speed)

        elif self.state == self.RDOWN_RUN:
            self.x = min(800, self.x + self.speed)
            self.y = max(0, self.y - self.speed)

        elif self.state == self.LEFT_RUN:
            if Map_RayCast_data[Location[1]][Location[0]] in (self.LEFT, self.All):
                self.x = max(0, self.x - self.speed)

        elif self.state == self.RIGHT_RUN:
            if Map_RayCast_data[Location[1]][Location[0]] in (self.RIGHT, self.All):
                self.x = min(800, self.x + self.speed)

        elif self.state == self.LUP_RUN:
            self.x = max(0, self.x - self.speed)
            self.y = min(600, self.y + self.speed)

        elif self.state == self.UP_RUN:
            if Map_RayCast_data[Location[1]][Location[0]] in (self.UP, self.All):
                self.y = min(600, self.y + self.speed)

        elif self.state == self.RUP_RUN:
            self.x = min(800, self.x + self.speed)
            self.y = min(600, self.y + self.speed)


    def draw(self):
        if self.state in (self.LDOWN_RUN, self.LEFT_RUN, self.LUP_RUN, self.UP_RUN):
            self.imgsheet = 0
        elif self.state in (self.RDOWN_RUN, self.RIGHT_RUN, self.RUP_RUN, self.DOWN_RUN):
            self.imgsheet = 1
        elif self.state == self.LEFT_STAND:
            self.imgsheet = 2
        elif self.state == self.RIGHT_STAND:
            self.imgsheet = 3

        self.image.clip_draw(self.frame * 100, self.imgsheet * 100, 100, 100, self.x, self.y)



def handle_events():
    global running
    global hero
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            running = False
        elif event.type == SDL_KEYDOWN and event.key == SDLK_ESCAPE:
            running = False
        else:
            hero.handle_event(event)
            pass


def main():

    open_canvas()

    global hero
    global running

    hero = Hero()
    grass = Grass()

    hero.Open_RayCast()
    running = True
    while running:
        handle_events()

        hero.update()

        clear_canvas()
        grass.draw()
        hero.draw()
        update_canvas()

        delay(0.04)

    close_canvas()


if __name__ == '__main__':
    main()