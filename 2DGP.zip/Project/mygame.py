import game_framework
import Start_state
import collision

game_framework.run(collision)
