import random
import json
import os

from pico2d import *

import game_framework
import title_state



name = "MainState"

brank = False
isPause = False
boy = None
grass = None
font = None
imgPause = None


class Grass:
    def __init__(self):
        self.image = load_image('grass.png')

    def draw(self):
        self.image.draw(400, 30)



class Boy:
    def __init__(self):
        self.x, self.y = 0, 90
        self.frame = 0
        self.image = load_image('run_animation.png')
        self.dir = 1

    def update(self):
        self.frame = (self.frame + 1) % 8
        self.x += self.dir
        if self.x >= 800:
            self.dir = -1
        elif self.x <= 0:
            self.dir = 1

    def draw(self):
        self.image.clip_draw(self.frame * 100, 0, 100, 100, self.x, self.y)


def enter():
    global boy, grass, imgPause
    boy = Boy()
    grass = Grass()
    imgPause = load_image('pause-512.png')
    pass


def exit():
    global boy, grass, imgPause
    del(boy)
    del(grass)
    del(imgPause)
    pass


def pause():
    global brank
    if isPause:
        if brank:
            imgPause.draw( 400, 300)
            delay(0.5)
            brank = False
        else:
            delay(0.5)
            brank = True
    pass


def resume():
    pass


def handle_events():
    global isPause
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()
        elif event.type == SDL_KEYDOWN and event.key == SDLK_ESCAPE:
            game_framework.change_state(title_state)
        elif event.type == SDL_KEYDOWN and event.key == SDLK_p:
            if isPause:
                isPause = False
            else:
                isPause = True
    pass


def update():
    if not isPause:
        boy.update()
    pass


def draw():
    clear_canvas()
    grass.draw()
    boy.draw()
    pause()
    update_canvas()
    pass





