import random

from pico2d import *

class Character:
    #캐릭터의 속성. 픽셀당 센티 및 움직이는 속도.
    PIXEL_PER_METER = (10.0 / 0.3)           # 10 pixel 30 cm
    RUN_SPEED_KMPH = 15.0                    # Km / Hour
    RUN_SPEED_MPM = (RUN_SPEED_KMPH * 1000.0 / 60.0)
    RUN_SPEED_MPS = (RUN_SPEED_MPM / 60.0)
    RUN_SPEED_PPS = (RUN_SPEED_MPS * PIXEL_PER_METER)

    TIME_PER_ACTION = 0.5
    ACTION_PER_TIME = 1.0 / TIME_PER_ACTION
    FRAMES_PER_ACTION = 8

    stand_image = None
    walk_image = None
    jump_fall_image = None

    #일반 STATE
    LEFT_RUN, RIGHT_RUN, LEFT_STAND, RIGHT_STAND = 0, 1, 2, 3

    #JUMP STATE
    JUMP, FALL, STAND = 4, 5, 6


    def __init__(self):
        self.x, self.y = 0, 70
        self.JumpY = 0
        self.frame = random.randint(0, 7)
        self.life_time = 0.0
        self.total_frames = 0.0
        self.dir = 0
        self.state = self.RIGHT_STAND
        self.jump_state = self.STAND
        if Character.walk_image == None:
            Character.walk_image = load_image('Walk_Sheet.png')

        if Character.stand_image == None:
            Character.stand_image = load_image('Stand_Sheet.png')

        if Character.jump_fall_image == None:
            Character.stand_image = load_image('Jump_Fall_Sheet.png')


    def update(self, frame_time):
        def clamp(minimum, x, maximum):
            return max(minimum, min(x, maximum))

        self.life_time += frame_time
        distance = Character.RUN_SPEED_PPS * frame_time
        self.total_frames += Character.FRAMES_PER_ACTION * Character.ACTION_PER_TIME * frame_time
        self.frame = int(self.total_frames) % 8
        self.x += (self.dir * distance)

        self.x = clamp(0, self.x, 800)

    def Jump(self):
        if self.jump_state in (self.JUMP,):
            pass
        pass

    def draw(self):
        if self.state in (self.LEFT_RUN, self.RIGHT_RUN):
            if self.jump_state in (self.JUMP, ):
                pass
            elif self.jump_state in (self.FALL, ):
                pass
            else:
                self.walk_image.clip_draw(self.frame * 32, self.state * 40, 32, 40, self.x, self.y)
        elif self.state in (self.LEFT_STAND, self.RIGHT_STAND):
            if self.jump_state in (self.JUMP, ):
                pass
            elif self.jump_state in (self.FALL, ):
                pass
            else:
                self.stand_image.clip_draw(0, (self.state - 2) * 40, 32, 40, self.x, self.y)

    def draw_bb(self):
        draw_rectangle(*self.get_bb())

    def get_bb(self):
        return self.x - 16, self.y - 20, self.x + 16, self.y + 16

    def handle_event(self, event):
        if (event.type, event.key) == (SDL_KEYDOWN, SDLK_LEFT):
            if self.state in (self.RIGHT_STAND, self.LEFT_STAND, self.RIGHT_RUN):
                self.state = self.LEFT_RUN
                self.dir = -1
        elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_RIGHT):
            if self.state in (self.RIGHT_STAND, self.LEFT_STAND, self.LEFT_RUN):
                self.state = self.RIGHT_RUN
                self.dir = 1
        elif (event.type, event.key) == (SDL_KEYUP, SDLK_LEFT):
            if self.state in (self.LEFT_RUN,):
                self.state = self.LEFT_STAND
                self.dir = 0
        elif (event.type, event.key) == (SDL_KEYUP, SDLK_RIGHT):
            if self.state in (self.RIGHT_RUN,):
                self.state = self.RIGHT_STAND
                self.dir = 0
        elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_UP):
            if self.jump_state in (self.STAND,):
                self.jump_state = self.JUMP






